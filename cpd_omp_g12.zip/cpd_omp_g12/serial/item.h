typedef struct{
	int cell;
	int num;
}Item;